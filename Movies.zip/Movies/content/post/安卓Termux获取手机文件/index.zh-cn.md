---
title: 安卓Termux获取手机文件
description: 
date: 2024-07-29
slug: termux-file
image: 
categories:
    - 教程
---

输入：
```
termux-setup-storage
```